coord	add_vectors		( coord a, coord b );
coord	subtract_vectors	( coord a, coord b );
double	inner_prod		( coord a, coord b );
coord	outer_prod		( coord a, coord b );
coord	normalize		( coord v );
