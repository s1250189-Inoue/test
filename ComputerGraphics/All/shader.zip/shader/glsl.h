#pragma

extern int	readShaderSource	( unsigned int shader, const char *file );
extern void	printShaderInfoLog	( unsigned int shader );
extern void	printProgramInfoLog	( unsigned int program );
